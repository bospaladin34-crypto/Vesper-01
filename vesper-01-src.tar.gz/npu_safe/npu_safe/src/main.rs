use std::{os::raw::{c_char, c_int, c_void}, ffi::CStr};
use libloading::{Library, Symbol};

type GetCount = unsafe extern "C" fn(*mut u32) -> c_int;
type GetDev = unsafe extern "C" fn(u32, *mut *mut c_void) -> c_int;
type GetName = unsafe extern "C" fn(*mut c_void, *mut *const c_char) -> c_int;

fn main(){
    println!("--- Safe NNAPI probe (fixed) ---");
    let lib = unsafe{ Library::new("libneuralnetworks.so").unwrap() };
    unsafe {
        let count: Symbol<GetCount> = lib.get(b"ANeuralNetworks_getDeviceCount").unwrap();
        let getdev: Symbol<GetDev> = lib.get(b"ANeuralNetworks_getDevice").unwrap();
        let getname: Symbol<GetName> = lib.get(b"ANeuralNetworksDevice_getName").unwrap();

        let mut n=0u32; count(&mut n);
        println!("Devices: {}", n);
        for i in 0..n {
            let mut dev: *mut c_void = std::ptr::null_mut();
            getdev(i, &mut dev);
            let mut name: *const c_char = std::ptr::null();
            getname(dev, &mut name);
            let s = CStr::from_ptr(name).to_string_lossy();
            println!(" [{}] {}", i, s);
        }
    }
}
