use std::{os::raw::{c_void,c_char,c_int}, time::Instant, ffi::CStr};
use libloading::{Library, Symbol};

#[repr(C)] struct Operand { ty:i32, dims:u32, dim:*const u32, scale:f32, zero:i32 }

fn main(){
    println!("--- TPU pulse (ADD on google-edgetpu) ---");
    let lib = unsafe{ Library::new("libneuralnetworks.so").unwrap() };
    unsafe {
        // load symbols
        let get_count: Symbol<unsafe extern "C" fn(*mut u32)->c_int> = lib.get(b"ANeuralNetworks_getDeviceCount").unwrap();
        let get_dev: Symbol<unsafe extern "C" fn(u32,*mut *mut c_void)->c_int> = lib.get(b"ANeuralNetworks_getDevice").unwrap();
        let get_name: Symbol<unsafe extern "C" fn(*mut c_void,*mut *const c_char)->c_int> = lib.get(b"ANeuralNetworksDevice_getName").unwrap();
        let model_create: Symbol<unsafe extern "C" fn(*mut *mut c_void)->c_int> = lib.get(b"ANeuralNetworksModel_create").unwrap();
        let add_op: Symbol<unsafe extern "C" fn(*mut c_void, *const Operand)->c_int> = lib.get(b"ANeuralNetworksModel_addOperand").unwrap();
        let set_val: Symbol<unsafe extern "C" fn(*mut c_void,i32,*const c_void,usize)->c_int> = lib.get(b"ANeuralNetworksModel_setOperandValue").unwrap();
        let add_oper: Symbol<unsafe extern "C" fn(*mut c_void,i32,u32,*const u32,u32,*const u32)->c_int> = lib.get(b"ANeuralNetworksModel_addOperation").unwrap();
        let id_io: Symbol<unsafe extern "C" fn(*mut c_void,u32,*const u32,u32,*const u32)->c_int> = lib.get(b"ANeuralNetworksModel_identifyInputsAndOutputs").unwrap();
        let finish_m: Symbol<unsafe extern "C" fn(*mut c_void)->c_int> = lib.get(b"ANeuralNetworksModel_finish").unwrap();
        let comp_create: Symbol<unsafe extern "C" fn(*mut c_void,*const *mut c_void,u32,*mut *mut c_void)->c_int> = lib.get(b"ANeuralNetworksCompilation_createForDevices").unwrap();
        let comp_finish: Symbol<unsafe extern "C" fn(*mut c_void)->c_int> = lib.get(b"ANeuralNetworksCompilation_finish").unwrap();
        let exec_create: Symbol<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->c_int> = lib.get(b"ANeuralNetworksExecution_create").unwrap();
        let set_in: Symbol<unsafe extern "C" fn(*mut c_void,i32,*const c_void,usize)->c_int> = lib.get(b"ANeuralNetworksExecution_setInput").unwrap();
        let set_out: Symbol<unsafe extern "C" fn(*mut c_void,i32,*mut c_void,usize)->c_int> = lib.get(b"ANeuralNetworksExecution_setOutput").unwrap();
        let compute: Symbol<unsafe extern "C" fn(*mut c_void)->c_int> = lib.get(b"ANeuralNetworksExecution_compute").unwrap();

        // get device 0
        let mut n=0; get_count(&mut n);
        let mut dev:*mut c_void = std::ptr::null_mut();
        get_dev(0,&mut dev);
        let mut nm:*const c_char = std::ptr::null();
        get_name(dev,&mut nm);
        println!("Using: {}", CStr::from_ptr(nm).to_string_lossy());

        // build tiny ADD model: out = a + b
        let mut model:*mut c_void = std::ptr::null_mut(); model_create(&mut model);
        let dim = [1u32]; let op_f = Operand{ty:0,dims:1,dim:dim.as_ptr(),scale:0.0,zero:0};
        let op_i = Operand{ty:2,dims:0,dim:std::ptr::null(),scale:0.0,zero:0}; // INT32
        add_op(model,&op_f); add_op(model,&op_f); add_op(model,&op_i); add_op(model,&op_f);
        let act:i32 = 0; set_val(model,2,&act as *const _ as *const c_void,4);
        let ins = [0u32,1,2]; let outs=[3u32]; add_oper(model,0,3,ins.as_ptr(),1,outs.as_ptr());
        let in_ids=[0u32,1]; let out_ids=[3u32]; id_io(model,2,in_ids.as_ptr(),1,out_ids.as_ptr());
        finish_m(model);

        let mut comp:*mut c_void = std::ptr::null_mut();
        comp_create(model,&dev,1,&mut comp); comp_finish(comp);

        // run 100 times
        let mut total=0u128;
        for _ in 0..100 {
            let mut exec:*mut c_void = std::ptr::null_mut(); exec_create(comp,&mut exec);
            let a:f32=1.234; let b:f32=5.678; let mut out:f32=0.0;
            set_in(exec,0,&a as *const _ as *const c_void,4);
            set_in(exec,1,&b as *const _ as *const c_void,4);
            set_out(exec,0,&mut out as *mut _ as *mut c_void,4);
            let t=Instant::now(); compute(exec); total+=t.elapsed().as_micros();
        }
        println!("Average TPU ADD: {} us", total/100);
        println!("Result check (should be ~6.912): {}", 1.234+5.678);
    }
}
