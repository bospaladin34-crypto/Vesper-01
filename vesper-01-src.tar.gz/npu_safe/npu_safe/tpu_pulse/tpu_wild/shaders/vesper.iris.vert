struct VertexIn {
  @location(0) position: vec3<f32>,
  @location(1) tensor_id: f32,
}
struct VertexOut {
  @builtin(position) pos: vec4<f32>,
  @location(0) v_id: f32,
}
@group(0) @binding(0) var<uniform> ViewProj: mat4x4<f32>;
@group(0) @binding(1) var<uniform> VesperState: vec4<f32>;
@vertex
fn main(in: VertexIn) -> VertexOut {
  var out: VertexOut;
  let scale = 1.0 + VesperState.x * 0.5;
  out.pos = ViewProj * vec4<f32>(in.position * scale, 1.0);
  out.v_id = in.tensor_id;
  return out;
}
