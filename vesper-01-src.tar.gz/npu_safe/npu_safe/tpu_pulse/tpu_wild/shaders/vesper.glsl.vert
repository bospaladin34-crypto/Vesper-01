#version 310 es

precision highp float;
precision highp int;

struct VertexIn {
    vec3 position;
    float tensor_id;
};
struct VertexOut {
    vec4 pos;
    float v_id;
};
uniform type_3_block_0Vertex { mat4x4 _group_0_binding_0_vs; };

uniform type_2_block_1Vertex { vec4 _group_0_binding_1_vs; };

layout(location = 0) in vec3 _p2vs_location0;
layout(location = 1) in float _p2vs_location1;
layout(location = 0) smooth out float _vs2fs_location0;

void main() {
    VertexIn in_ = VertexIn(_p2vs_location0, _p2vs_location1);
    VertexOut out_ = VertexOut(vec4(0.0), 0.0);
    float _e4 = _group_0_binding_1_vs.x;
    float scale = (1.0 + (_e4 * 0.5));
    mat4x4 _e11 = _group_0_binding_0_vs;
    out_.pos = (_e11 * vec4((in_.position * scale), 1.0));
    out_.v_id = in_.tensor_id;
    VertexOut _e19 = out_;
    gl_Position = _e19.pos;
    _vs2fs_location0 = _e19.v_id;
    gl_Position.yz = vec2(-gl_Position.y, gl_Position.z * 2.0 - gl_Position.w);
    return;
}

