#version 310 es

precision highp float;
precision highp int;

uniform type_block_0Fragment { vec4 _group_0_binding_1_fs; };

layout(location = 0) smooth in float _vs2fs_location0;
layout(location = 0) out vec4 _fs2p_location0;

void main() {
    float id = _vs2fs_location0;
    vec3 color = vec3(0.2, 0.5, 1.0);
    float phase = _group_0_binding_1_fs.z;
    if ((phase > 1.5)) {
        color = vec3(1.0, 0.9, 0.2);
    }
    if ((phase > 2.5)) {
        color = vec3(1.0, 0.2, 0.2);
    }
    if ((phase > 3.5)) {
        color = vec3(0.2, 1.0, 0.4);
    }
    float _e31 = _group_0_binding_1_fs.w;
    float pulse = (0.8 + (0.2 * sin(((id * 0.01) + (_e31 * 10.0)))));
    vec3 _e40 = color;
    _fs2p_location0 = vec4((_e40 * pulse), 1.0);
    return;
}

