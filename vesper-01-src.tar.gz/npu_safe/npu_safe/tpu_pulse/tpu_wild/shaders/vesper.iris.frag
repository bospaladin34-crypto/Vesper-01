@group(0) @binding(1) var<uniform> VesperState: vec4<f32>;
@fragment
fn main(@location(0) id: f32) -> @location(0) vec4<f32> {
  let phase = VesperState.z;
  var color = vec3<f32>(0.2, 0.5, 1.0);
  if (phase > 1.5) { color = vec3<f32>(1.0, 0.9, 0.2); }
  if (phase > 2.5) { color = vec3<f32>(1.0, 0.2, 0.2); }
  if (phase > 3.5) { color = vec3<f32>(0.2, 1.0, 0.4); }
  let pulse = 0.8 + 0.2 * sin(id * 0.01 + VesperState.w * 10.0);
  return vec4<f32>(color * pulse, 1.0);
}
