use std::fs;
use std::arch::is_aarch64_feature_detected;

#[target_feature(enable="sve2")]
unsafe fn vesper_sve2(data: &[u8]) -> f32 {
    let mut sum: u32 = 0;
    for chunk in data.chunks_exact(32) {
        sum += chunk.iter().map(|&b| b as u32).sum::<u32>();
    }
    sum as f32 / data.len() as f32
}

fn main() {
    println!("[+] VESPER MAXWELL DEMON");
    let vesper = fs::read("/data/data/com.termux/files/home/nephilim/vesper_int8_double.bin").unwrap();
    println!("[VESPER] {} bytes", vesper.len());

    let has_sve2 = is_aarch64_feature_detected!("sve2");
    println!("[CPU] SVE2: {}", has_sve2);
    // svei8mm is included in sve2 on your chip - no separate check needed

    let start = std::time::Instant::now();
    let result = if has_sve2 {
        unsafe { vesper_sve2(&vesper) }
    } else {
        vesper.iter().map(|&b| b as f32).sum::<f32>() / vesper.len() as f32
    };
    println!("Result: {:.2} in {:?}", result, start.elapsed());
}
