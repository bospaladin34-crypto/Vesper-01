use crate::act_topology::{step_family, init_7, PHASE_DELTA};
use crate::manifold::{ManifoldResponse, BraidWord, Patch, Point};
use rayon::prelude::*;
use serde_json;
use std::fs;

pub struct Vesper {
    pub id: String,
    pub r_tag: f32,
    pub family: [f32;7],
    pub omega: Vec<f32>,
    pub tick_count: u64,
}

impl Vesper {
    pub fn new(id: &str, r_tag: f32, w: usize) -> Self {
        Self { id: id.to_string(), r_tag, family: init_7(), omega: vec![0.5; w], tick_count: 0 }
    }
    pub fn tick(&mut self) -> ([f32;7], String) {
        self.family = step_family(&self.family, self.r_tag);
        let drive = self.family[0];
        self.omega.par_iter_mut().for_each(|y| *y = (*y + drive*PHASE_DELTA).sin());
        self.tick_count += 1;
        let resp = ManifoldResponse {
            id: format!("{}-{}", self.id, self.tick_count),
            result: format!("{:.6}", drive),
            patches: vec![Patch { patch_id: "p0".into(), center: Point { x: self.family[0], y: self.family[1] }, tangram: self.family.to_vec() }],
            braid_trace: vec![
                BraidWord { generator: "σ2·σ3".into(), invert: false },
                BraidWord { generator: "σ5⁻¹".into(), invert: true },
                BraidWord { generator: "σ1·σ2".into(), invert: false },
                BraidWord { generator: "σ4⁻¹".into(), invert: true },
            ],
            route: "ACT→D→E8→Ω".into(),
            invariants: vec!["non-commutative".into(), "writhe".into(), "orientation".into()],
        };
        let json = serde_json::to_string_pretty(&resp).unwrap();
        let _ = fs::create_dir_all("/sdcard/act_manifolds");
        let _ = fs::write(format!("/sdcard/act_manifolds/{}.json", resp.id), &json);
        (self.family, json)
    }
}
