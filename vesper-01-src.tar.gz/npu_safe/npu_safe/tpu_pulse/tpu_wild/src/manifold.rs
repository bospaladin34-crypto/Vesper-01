use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize)]
pub struct Point {
    pub x: f32,
    pub y: f32,
}

#[derive(Serialize, Deserialize)]
pub struct Patch {
    #[serde(rename = "patchId")]
    pub patch_id: String,
    pub center: Point,
    pub tangram: Vec<f32>,
}

#[derive(Serialize, Deserialize)]
pub struct BraidWord {
    pub generator: String,
    pub invert: bool,
}

#[derive(Serialize, Deserialize)]
pub struct ManifoldResponse {
    pub id: String,
    pub result: String,
    pub patches: Vec<Patch>,
    #[serde(rename = "braidTrace")]
    pub braid_trace: Vec<BraidWord>,
    pub route: String,
    pub invariants: Vec<String>,
}
