use ash::vk;
use ndk_sys::AHardwareBuffer;

pub struct VulkanDevice {
    pub device: ash::Device,
}

pub struct VulkanBuffer {
    pub buffer: vk::Buffer,
    pub memory: vk::DeviceMemory,
}

#[no_mangle]
pub unsafe extern "C" fn iris_import_ahb_vulkan(
    device: *mut crate::IrisDevice,
    ahb: *mut AHardwareBuffer,
) -> *mut crate::IrisBuffer {
    let dev = &mut *(device as *mut VulkanDevice);
    let mut desc: ndk_sys::AHardwareBuffer_Desc = std::mem::zeroed();
    ndk_sys::AHardwareBuffer_describe(ahb, &mut desc);
    let size = 116825u64; // your vesper file

    let buf_info = vk::BufferCreateInfo::builder().size(size)
       .usage(vk::BufferUsageFlags::VERTEX_BUFFER | vk::BufferUsageFlags::STORAGE_BUFFER);
    let buffer = dev.device.create_buffer(&buf_info, None).unwrap();

    let import = vk::ImportAndroidHardwareBufferInfoANDROID::builder().buffer(ahb);
    let alloc = vk::MemoryAllocateInfo::builder().allocation_size(size)
       .push_next(&mut import.clone());
    let memory = dev.device.allocate_memory(&alloc, None).unwrap();
    dev.device.bind_buffer_memory(buffer, memory, 0).unwrap();

    let vb = Box::new(VulkanBuffer { buffer, memory });
    Box::into_raw(vb) as *mut crate::IrisBuffer
}
