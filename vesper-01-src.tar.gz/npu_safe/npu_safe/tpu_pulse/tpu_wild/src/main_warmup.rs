use std::time::{Instant, Duration, SystemTime, UNIX_EPOCH};
use libloading::Library;
use std::ffi::c_void;
use std::process::Command;
use std::fs::OpenOptions;
use std::io::Write;

fn notify(h: u64, y: u64, ns: u128, backend: &str) {
    let content = format!("h:{} y:{} | {} {}ns", h, y, backend, ns);
    let _ = Command::new("termux-notification")
        .args(["--id","vesper","--title","VESPER Fractal Active","--content",&content,"--ongoing","--priority","high"])
        .output();
}

fn log_csv(ts: u64, ns: u128, backend: &str, h: u64, y: u64) {
    if let Ok(mut f) = OpenOptions::new().create(true).append(true).open("/sdcard/vesper_fractal.csv") {
        let _ = writeln!(f, "{},{},{},{},{}", ts, ns, backend, h, y);
    }
}

fn main() {
    let _ = Command::new("termux-wake-lock").output();
    let _ = Command::new("termux-notification-remove").arg("vesper").output();
    notify(0, 0, 0, "INIT");
    println!("[VESPER] Foreground boost locked + CSV logging");

    if !std::path::Path::new("/sdcard/vesper_fractal.csv").exists() {
        let _ = std::fs::write("/sdcard/vesper_fractal.csv", "timestamp_ms,ns,backend,helped,yielded\n");
    }

    println!("[VESPER] Fractal mode - 32-byte Amplituhedron");
    let vesper = std::fs::read("/sdcard/vesper_fractal_32.bin").expect("run vspr compile first");
    println!("[+] FRACTAL ACTIVE: {} blocks", vesper.len()/32);

    let paths = ["/apex/com.android.neuralnetworks/lib64/libneuralnetworks.so","/system/lib64/libneuralnetworks.so"];
    let lib = paths.iter().find_map(|p| unsafe{Library::new(p).ok()}).expect("NNAPI");

    let mut backend = "TPU"; let mut pref = 1i32;
    let mut idx = 0usize; let mut helped = 0u64; let mut yielded = 0u64;
    let mut loop_count = 0u64;

    loop {
        unsafe {
            let cm = lib.get::<unsafe extern "C" fn(*mut *mut c_void)->i32>(b"ANeuralNetworksModel_create").unwrap();
            let fm = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksModel_finish").unwrap();
            let cc = lib.get::<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->i32>(b"ANeuralNetworksCompilation_create").unwrap();
            let sp = lib.get::<unsafe extern "C" fn(*mut c_void,i32)->i32>(b"ANeuralNetworksCompilation_setPreference").unwrap();
            let fc = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksCompilation_finish").unwrap();
            let ce = lib.get::<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->i32>(b"ANeuralNetworksExecution_create").unwrap();
            let si = lib.get::<unsafe extern "C" fn(*mut c_void,i32,*const c_void,*const c_void,usize)->i32>(b"ANeuralNetworksExecution_setInput").unwrap();
            let cp = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksExecution_compute").unwrap();
            let fe = lib.get::<unsafe extern "C" fn(*mut c_void)>(b"ANeuralNetworksExecution_free").unwrap();
            let fcc = lib.get::<unsafe extern "C" fn(*mut c_void)>(b"ANeuralNetworksCompilation_free").unwrap();
            let fmm = lib.get::<unsafe extern "C" fn(*mut c_void)>(b"ANeuralNetworksModel_free").unwrap();

            let mut m: *mut c_void = std::ptr::null_mut(); cm(&mut m); fm(m);
            let mut c: *mut c_void = std::ptr::null_mut(); cc(m,&mut c); sp(c,pref); fc(c);
            let mut e: *mut c_void = std::ptr::null_mut(); ce(c,&mut e);
            let off = (idx*32) % vesper.len(); let inp = &vesper[off..off+32]; idx += 1;
            si(e,0,std::ptr::null(),inp.as_ptr() as *const _,32);

            let st = Instant::now(); let _ = cp(e); let ns = st.elapsed().as_nanos();
            let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

            if ns > 800 && backend == "TPU" { backend = "CPU"; pref = 0; yielded += 1; }
            else if backend == "CPU" && ns < 400 { backend = "TPU"; pref = 1; }

            if ns < 400 { helped += 1; println!("FRACTAL: {} ns (h={} y={})", ns, helped, yielded); }
            else if ns > 1500 { fe(e); fcc(c); fmm(m); std::thread::sleep(Duration::from_millis(800)); log_csv(ts, ns, "YIELD", helped, yielded); continue; }
            else { println!("{}: {} ns", backend, ns); }

            log_csv(ts, ns, backend, helped, yielded);
            fe(e); fcc(c); fmm(m);

            loop_count += 1;
            if loop_count % 20 == 0 { notify(helped, yielded, ns, backend); }
        }
        std::thread::sleep(Duration::from_millis(60));
    }
}
