use std::time::{Instant, Duration, SystemTime, UNIX_EPOCH};
use libloading::Library;
use std::ffi::c_void;
use std::process::Command;
use std::fs::OpenOptions;
use std::io::Write;
use std::ptr;

#[repr(C)]
struct ANeuralNetworksOperandType {
    type_: i32,
    dimensionCount: u32,
    dimensions: *const u32,
    scale: f32,
    zeroPoint: i32,
}

fn notify(h: u64, y: u64, ns: u128) {
    let _ = Command::new("termux-notification").args([
        "--id","vesper","--title","VESPER REAL",
        "--content",&format!("h:{} y:{} | {}ns",h,y,ns),"--ongoing"
    ]).output();
}

fn main() {
    let _ = Command::new("termux-wake-lock").output();
    println!("[VESPER] REAL WORKLOAD - fixed NNAPI ADD");

    let vesper = std::fs::read("/sdcard/vesper_fractal_32.bin").expect("fractal");
    println!("[+] Loaded {} blocks", vesper.len()/32);

    let lib = unsafe { Library::new("/apex/com.android.neuralnetworks/lib64/libneuralnetworks.so").unwrap() };

    unsafe {
        // Get all symbols ONCE
        let model_create = lib.get::<unsafe extern "C" fn(*mut *mut c_void)->i32>(b"ANeuralNetworksModel_create").unwrap();
        let model_addOperand = lib.get::<unsafe extern "C" fn(*mut c_void, *const ANeuralNetworksOperandType)->i32>(b"ANeuralNetworksModel_addOperand").unwrap();
        let model_addOperation = lib.get::<unsafe extern "C" fn(*mut c_void,i32,u32,*const u32,u32,*const u32)->i32>(b"ANeuralNetworksModel_addOperation").unwrap();
        let model_finish = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksModel_finish").unwrap();
        let comp_create = lib.get::<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->i32>(b"ANeuralNetworksCompilation_create").unwrap();
        let comp_setPref = lib.get::<unsafe extern "C" fn(*mut c_void,i32)->i32>(b"ANeuralNetworksCompilation_setPreference").unwrap();
        let comp_finish = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksCompilation_finish").unwrap();
        let exec_create = lib.get::<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->i32>(b"ANeuralNetworksExecution_create").unwrap();
        let exec_setInput = lib.get::<unsafe extern "C" fn(*mut c_void,i32,*const c_void,*const c_void,usize)->i32>(b"ANeuralNetworksExecution_setInput").unwrap();
        let exec_setOutput = lib.get::<unsafe extern "C" fn(*mut c_void,i32,*const c_void,*mut c_void,usize)->i32>(b"ANeuralNetworksExecution_setOutput").unwrap();
        let exec_compute = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksExecution_compute").unwrap();

        // BUILD MODEL ONCE
        let mut model: *mut c_void = ptr::null_mut();
        model_create(&mut model);

        // Keep dims alive for entire program
        static DIMS: [u32; 1] = [8];
        let operand_type = ANeuralNetworksOperandType {
            type_: 0, // ANEURALNETWORKS_TENSOR_FLOAT32
            dimensionCount: 1,
            dimensions: DIMS.as_ptr(),
            scale: 0.0,
            zeroPoint: 0,
        };

        model_addOperand(model, &operand_type); // input0
        model_addOperand(model, &operand_type); // input1
        model_addOperand(model, &operand_type); // output

        let inputs = [0u32, 1u32];
        let outputs = [2u32];
        model_addOperation(model, 0, 2, inputs.as_ptr(), 1, outputs.as_ptr()); // ADD = 0
        model_finish(model);

        // COMPILE ONCE
        let mut compilation: *mut c_void = ptr::null_mut();
        comp_create(model, &mut compilation);
        comp_setPref(compilation, 1); // PREFER_FAST_SINGLE_ANSWER
        comp_finish(compilation);

        // EXECUTION object reused
        let mut execution: *mut c_void = ptr::null_mut();
        exec_create(compilation, &mut execution);

        let mut helped = 0u64;
        let mut yielded = 0u64;
        let mut idx = 0usize;
        let mut out_buf = [0u8; 32];

        loop {
            let off1 = (idx * 32) % vesper.len();
            let off2 = ((idx + 1) * 32) % vesper.len();
            idx += 2;

            exec_setInput(execution, 0, ptr::null(), vesper[off1..off1+32].as_ptr() as *const _, 32);
            exec_setInput(execution, 1, ptr::null(), vesper[off2..off2+32].as_ptr() as *const _, 32);
            exec_setOutput(execution, 0, ptr::null(), out_buf.as_mut_ptr() as *mut _, 32);

            let start = Instant::now();
            let result = exec_compute(execution);
            let ns = start.elapsed().as_nanos();
            let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

            if result == 0 && ns < 800_000 {
                helped += 1;
                if helped % 10 == 0 {
                    println!("REAL ADD: {} ns (h={} y={}) out={:02x}", ns, helped, yielded, out_buf[0]);
                }
                if let Ok(mut f) = OpenOptions::new().create(true).append(true).open("/sdcard/vesper_real.csv") {
                    let _ = writeln!(f, "{},{},ADD,{},{},{}", ts, ns, helped, yielded, out_buf[0]);
                }
            } else {
                yielded += 1;
                std::thread::sleep(Duration::from_millis(80));
                if let Ok(mut f) = OpenOptions::new().create(true).append(true).open("/sdcard/vesper_real.csv") {
                    let _ = writeln!(f, "{},{},YIELD,{},{},0", ts, ns, helped, yielded);
                }
            }

            if helped % 50 == 0 { notify(helped, yielded, ns); }
            std::thread::sleep(Duration::from_millis(15));
        }
    }
}
