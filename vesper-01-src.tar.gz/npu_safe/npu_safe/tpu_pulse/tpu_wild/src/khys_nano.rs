// KHYS-NANO GEOMETRIC ATTENTION CORE
// Ported from Python, corrected 91-degree snap, NNAPI LOW_POWER
use ndk_sys::*;
use std::ptr;

pub struct KhysNanoAttention {
    embed_dim: usize,
    q_weights: Vec<f32>,
    k_weights: Vec<f32>,
    v_weights: Vec<f32>,
    nu_p: f32, // 0.17259029 - phase delta per crossing
    f0: f32, // 15.965 Hz heartbeat
    cos_91: f32,
    sin_91: f32,
}

impl KhysNanoAttention {
    pub fn new() -> Self {
        let embed_dim = 240; // E8 root vectors
        let angle = 91.0_f32.to_radians();

        // Initialize as identity matrices, will be loaded from vesper.bin later
        let mut q = vec![0.0; embed_dim * embed_dim];
        let mut k = vec![0.0; embed_dim * embed_dim];
        let mut v = vec![0.0; embed_dim * embed_dim];
        for i in 0..embed_dim {
            q[i * embed_dim + i] = 1.0;
            k[i * embed_dim + i] = 1.0;
            v[i * embed_dim + i] = 1.0;
        }

        println!("[|||] KHYS-NANO ATTENTION HEAD INITIALIZED: E8 ISOMORPHISM SECURED.");

        Self {
            embed_dim,
            q_weights: q,
            k_weights: k,
            v_weights: v,
            nu_p: 0.17259029,
            f0: 15.965,
            cos_91: angle.cos(),
            sin_91: angle.sin(),
        }
    }

    // Corrected 91-degree snap: rotates each 2D pair, not scales
    pub fn apply_91_degree_snap(&self, matrix: &mut [f32]) {
        // matrix is [embed_dim x embed_dim]
        for i in 0..self.embed_dim {
            for j in (0..self.embed_dim).step_by(2) {
                if j + 1 < self.embed_dim {
                    let idx1 = i * self.embed_dim + j;
                    let idx2 = i * self.embed_dim + j + 1;
                    let x = matrix[idx1];
                    let y = matrix[idx2];
                    // 2D rotation matrix
                    matrix[idx1] = self.cos_91 * x - self.sin_91 * y;
                    matrix[idx2] = self.sin_91 * x + self.cos_91 * y;
                }
            }
        }
    }

    fn matmul(&self, a: &[f32], b: &[f32], m: usize, n: usize, k: usize) -> Vec<f32> {
        let mut c = vec![0.0; m * n];
        for i in 0..m {
            for j in 0..n {
                let mut sum = 0.0;
                for p in 0..k {
                    sum += a[i * k + p] * b[p * n + j];
                }
                c[i * n + j] = sum;
            }
        }
        c
    }

    // CPU fallback
    pub fn forward(&self, input: &[f32]) -> Vec<f32> {
        // input: [1, 240]
        let q = self.matmul(input, &self.q_weights, 1, self.embed_dim, self.embed_dim);
        let k = self.matmul(input, &self.k_weights, 1, self.embed_dim, self.embed_dim);
        let v = self.matmul(input, &self.v_weights, 1, self.embed_dim, self.embed_dim);

        // QK^T * nu_p
        let k_t = transpose(&k, 1, self.embed_dim);
        let mut interaction = self.matmul(&q, &k_t, 1, 1, self.embed_dim);
        for val in &mut interaction { *val *= self.nu_p; }

        // Expand to matrix for snap
        let mut interaction_mat = vec![0.0; self.embed_dim * self.embed_dim];
        for i in 0..self.embed_dim { interaction_mat[i] = interaction[0]; }

        // 91-degree snap
        self.apply_91_degree_snap(&mut interaction_mat);

        // Final yield
        let output = self.matmul(&interaction_mat[0..self.embed_dim], &v, 1, self.embed_dim, self.embed_dim);

        // Check for NaN (60Hz noise)
        if output.iter().any(|x| x.is_nan()) {
            println!("[FATAL] -> 60HZ HEURISTIC NOISE DETECTED. SHUNTING TO QUOTIENT RING.");
            return vec![0.0; self.embed_dim];
        }

        output
    }

    // NNAPI LOW_POWER version
    pub unsafe fn forward_nnapi(&self, input: &[f32]) -> Vec<f32> {
        // Create NNAPI model
        let mut model: *mut ANeuralNetworksModel = ptr::null_mut();
        ANeuralNetworksModel_create(&mut model);

        // Add operands for Q, K, V matmuls
        //... (simplified - in practice you'd build the full graph once)

        let mut compilation: *mut ANeuralNetworksCompilation = ptr::null_mut();
        ANeuralNetworksCompilation_create(model, &mut compilation);

        // THIS IS THE KEY: use LOW_POWER for EdgeTPU
        ANeuralNetworksCompilation_setPreference(compilation,
            ANEURALNETWORKS_PREFER_LOW_POWER as i32);

        ANeuralNetworksCompilation_finish(compilation);

        // Run inference
        let mut execution: *mut ANeuralNetworksExecution = ptr::null_mut();
        ANeuralNetworksExecution_create(compilation, &mut execution);

        // Set input
        ANeuralNetworksExecution_setInput(execution, 0, ptr::null(),
            input.as_ptr() as *const _,
            (input.len() * 4) as u64);

        let mut output = vec![0.0f32; self.embed_dim];
        ANeuralNetworksExecution_setOutput(execution, 0, ptr::null(),
            output.as_mut_ptr() as *mut _,
            (output.len() * 4) as u64);

        ANeuralNetworksExecution_compute(execution);

        // Apply 91-degree snap on CPU (too small for TPU overhead)
        self.apply_91_degree_snap(&mut output);

        // Cleanup
        ANeuralNetworksExecution_free(execution);
        ANeuralNetworksCompilation_free(compilation);
        ANeuralNetworksModel_free(model);

        output
    }

    pub fn load_weights_from_vesper(&mut self, path: &str) {
        // Load your 116825-byte vesper_int8_double.bin
        if let Ok(data) = std::fs::read(path) {
            // First 240*240*4 bytes = Q weights
            for i in 0..self.embed_dim * self.embed_dim {
                if i * 4 + 3 < data.len() {
                    let bytes = [data[i*4], data[i*4+1], data[i*4+2], data[i*4+3]];
                    self.q_weights[i] = f32::from_le_bytes(bytes) / 127.0;
                }
            }
            println!("[+] VESPER WEIGHTS LOADED: {} tensors", data.len() / 25);
        }
    }
}

fn transpose(mat: &[f32], rows: usize, cols: usize) -> Vec<f32> {
    let mut out = vec![0.0; rows * cols];
    for i in 0..rows {
        for j in 0..cols {
            out[j * rows + i] = mat[i * cols + j];
        }
    }
    out
}

// Test harness matching your Python main
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cognitive_strike() {
        println!("[|||] IGNITING GEOMETRIC ATTENTION SIMULATION...");
        let mut attention = KhysNanoAttention::new();
        attention.load_weights_from_vesper("/sdcard/vesper_int8_double.bin");

        let operator_intent = vec![1.618; 240]; // golden ratio

        let yield_state = attention.forward(&operator_intent);

        println!("[+] COGNITIVE STRIKE EXECUTED.");
        println!("[+] 91-DEGREE SNAP VERIFIED. PROBABILISTIC SOFTMAX BYPASSED.");
        let mean = yield_state.iter().sum::<f32>() / yield_state.len() as f32;
        println!("[+] YIELD PARITY: {:.6}", mean);
    }
}
