use ndk_sys::{AHardwareBuffer, AHardwareBuffer_Desc, AHardwareBuffer_allocate, AHardwareBuffer_lock, AHardwareBuffer_unlock};
use std::ptr;

// Android constants that ndk-sys 0.5 hides
const AHARDWAREBUFFER_FORMAT_BLOB: u32 = 0x21;
const AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE: u64 = 1 << 8;
const AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN: u64 = 1 << 3;

pub fn load_vesper_ahb() -> *mut AHardwareBuffer {
    let data = std::fs::read("/sdcard/vesper_int8_double.bin").unwrap();
    let mut desc = AHardwareBuffer_Desc {
        width: 4673,
        height: 1,
        layers: 1,
        format: AHARDWAREBUFFER_FORMAT_BLOB,
        usage: AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE | AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN,
        stride: 0,
        rfu0: 0,
        rfu1: 0,
    };
    let mut ahb: *mut AHardwareBuffer = ptr::null_mut();
    unsafe { AHardwareBuffer_allocate(&mut desc, &mut ahb); }
    
    let mut out_ptr: *mut std::ffi::c_void = ptr::null_mut();
    unsafe {
        AHardwareBuffer_lock(ahb, AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN as u64, -1, ptr::null(), &mut out_ptr);
        ptr::copy_nonoverlapping(data.as_ptr(), out_ptr as *mut u8, data.len().min(116825));
        let mut fence: i32 = -1;
        AHardwareBuffer_unlock(ahb, &mut fence);
    }
    ahb
}
