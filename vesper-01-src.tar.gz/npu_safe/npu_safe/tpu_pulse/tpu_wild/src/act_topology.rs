pub const PHI: f32 = 1.6180339887;
pub const INV_PHI: f32 = 0.6180339887; // e^{-ΔE/T}
pub const CHI: f32 = 0.17259029; // νₚ from TC-UFT
pub const PHASE_DELTA: f32 = CHI;
const ROT_108: f32 = 1.884955592;

#[inline(always)]
fn braid(s: &mut [f32;7], i: usize, j: usize, invert: bool, weight: f32) {
    let t = s[i];
    if invert {
        s[i] = -s[j] * PHI * weight;
        s[j] = -t * PHI * weight;
    } else {
        s[i] = s[j] * weight;
        s[j] = t * weight;
    }
}

pub fn step_family(input: &[f32;7], r_tag: f32) -> [f32;7] {
    let mut st = *input;
    // ACT → D (weight = INV_PHI)
    braid(&mut st, 2, 3, false, INV_PHI);
    braid(&mut st, 5, 6, true, INV_PHI);
    // D → E8 (weight = PHI)
    braid(&mut st, 1, 2, false, PHI);
    braid(&mut st, 4, 5, true, PHI);
    // E8 rotation with χ coupling
    let c = ROT_108.cos(); let s = ROT_108.sin();
    let x0 = st[0]; let x1 = st[1];
    let w_e8 = 1.0 + CHI * r_tag; // 1 + χR
    st[0] = (c*x0 - s*x1) * w_e8;
    st[1] = (s*x0 + c*x1) * w_e8;
    // Ω phase lock
    for v in &mut st { *v *= PHASE_DELTA; }
    let tr: f32 = st.iter().map(|v| v.abs()).sum();
    if tr > 0.0 { let inv = 1.0/tr; for v in &mut st { *v *= inv; } }
    st
}

pub fn init_7() -> [f32;7] { [1.0;7] }
