use glow::HasContext;
use ndk_sys::AHardwareBuffer;
use std::os::raw::{c_void, c_int};

// EGL types that ndk-sys doesn't expose
type EGLDisplay = *mut c_void;
type EGLClientBuffer = *mut c_void;
type EGLImageKHR = *mut c_void;
const EGL_NO_CONTEXT: EGLDisplay = 0 as _;
const EGL_NONE: c_int = 0x3038;
const EGL_TRUE: c_int = 1;
const EGL_IMAGE_PRESERVED_KHR: c_int = 0x30D2;
const EGL_NATIVE_BUFFER_ANDROID: c_int = 0x3140;

pub struct GlesDevice {
    pub gl: glow::Context,
    pub egl_display: EGLDisplay,
    pub egl_get_native_client_buffer: unsafe extern "C" fn(*mut AHardwareBuffer) -> EGLClientBuffer,
    pub egl_create_image: unsafe extern "C" fn(EGLDisplay, EGLDisplay, c_int, EGLClientBuffer, *const c_int) -> EGLImageKHR,
    pub egl_destroy_image: unsafe extern "C" fn(EGLDisplay, EGLImageKHR) -> u32,
    pub gl_egl_image_target_texture_2d: unsafe extern "C" fn(u32, EGLImageKHR),
}

pub struct GlesBuffer {
    pub texture: glow::Texture,
    pub egl_image: EGLImageKHR,
}

#[no_mangle]
pub unsafe extern "C" fn iris_import_ahb(
    device: *mut crate::IrisDevice,
    ahb: *mut AHardwareBuffer,
) -> *mut crate::IrisBuffer {
    let dev = &mut *(device as *mut GlesDevice);
    let gl = &dev.gl;

    let client = (dev.egl_get_native_client_buffer)(ahb);
    let attrs = [EGL_IMAGE_PRESERVED_KHR, EGL_TRUE, EGL_NONE];
    let image = (dev.egl_create_image)(dev.egl_display, EGL_NO_CONTEXT, EGL_NATIVE_BUFFER_ANDROID, client, attrs.as_ptr());

    let tex = gl.create_texture().unwrap();
    gl.bind_texture(glow::TEXTURE_2D, Some(tex));
    (dev.gl_egl_image_target_texture_2d)(glow::TEXTURE_2D, image);

    gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER, glow::NEAREST as i32);
    gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MAG_FILTER, glow::NEAREST as i32);

    let buf = Box::new(GlesBuffer { texture: tex, egl_image: image });
    Box::into_raw(buf) as *mut crate::IrisBuffer
}

#[no_mangle]
pub unsafe extern "C" fn iris_destroy_ahb_buffer(
    device: *mut crate::IrisDevice,
    buffer: *mut crate::IrisBuffer,
) {
    let dev = &mut *(device as *mut GlesDevice);
    let buf = Box::from_raw(buffer as *mut GlesBuffer);
    dev.gl.delete_texture(buf.texture);
    (dev.egl_destroy_image)(dev.egl_display, buf.egl_image);
}
