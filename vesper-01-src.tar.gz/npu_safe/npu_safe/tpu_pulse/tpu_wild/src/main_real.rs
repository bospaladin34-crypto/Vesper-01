use std::time::{Instant, Duration, SystemTime, UNIX_EPOCH};
use libloading::Library;
use std::ffi::c_void;
use std::process::Command;
use std::fs::OpenOptions;
use std::io::Write;

fn notify(h: u64, y: u64, ns: u128) {
    let _ = Command::new("termux-notification").args([
        "--id","vesper","--title","VESPER REAL WORKLOAD",
        "--content",&format!("h:{} y:{} | {}ns",h,y,ns),
        "--ongoing"
    ]).output();
}

fn log_csv(ts: u64, ns: u128, op: &str, h: u64, y: u64) {
    if let Ok(mut f) = OpenOptions::new().create(true).append(true).open("/sdcard/vesper_real.csv") {
        let _ = writeln!(f, "{},{},{},{},{}", ts, ns, op, h, y);
    }
}

fn main() {
    let _ = Command::new("termux-wake-lock").output();
    println!("[VESPER] REAL WORKLOAD MODE - ADD operation on fractal blocks");

    let vesper = std::fs::read("/sdcard/vesper_fractal_32.bin").expect("fractal file");
    println!("[+] Loaded {} fractal blocks", vesper.len()/32);

    let lib = unsafe { Library::new("/apex/com.android.neuralnetworks/lib64/libneuralnetworks.so").unwrap() };

    let mut helped = 0u64; let mut yielded = 0u64; let mut idx = 0usize;

    loop {
        unsafe {
            // Build a REAL model: ADD two 8-float tensors
            let create = lib.get::<unsafe extern "C" fn(*mut *mut c_void)->i32>(b"ANeuralNetworksModel_create").unwrap();
            let add_operand = lib.get::<unsafe extern "C" fn(*mut c_void,*const u32)->i32>(b"ANeuralNetworksModel_addOperand").unwrap();
            let add_op = lib.get::<unsafe extern "C" fn(*mut c_void,i32,u32,*const u32,u32,*const u32)->i32>(b"ANeuralNetworksModel_addOperation").unwrap();
            let finish = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksModel_finish").unwrap();

            let mut model: *mut c_void = std::ptr::null_mut();
            create(&mut model);

            // Define tensor type: 8 floats (32 bytes)
            let dims = [8u32];
            let tensor_type = [6u32, 1, dims[0]]; // FLOAT32

            add_operand(model, tensor_type.as_ptr()); // input0
            add_operand(model, tensor_type.as_ptr()); // input1
            add_operand(model, tensor_type.as_ptr()); // output

            let inputs = [0u32, 1u32];
            let outputs = [2u32];
            add_op(model, 0, 2, inputs.as_ptr(), 1, outputs.as_ptr()); // ANEURALNETWORKS_ADD = 0
            finish(model);

            // Compile
            let cc = lib.get::<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->i32>(b"ANeuralNetworksCompilation_create").unwrap();
            let sp = lib.get::<unsafe extern "C" fn(*mut c_void,i32)->i32>(b"ANeuralNetworksCompilation_setPreference").unwrap();
            let fc = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksCompilation_finish").unwrap();

            let mut comp: *mut c_void = std::ptr::null_mut();
            cc(model, &mut comp);
            sp(comp, 1); // PREFER_FAST_SINGLE_ANSWER
            fc(comp);

            // Execute with REAL data
            let ce = lib.get::<unsafe extern "C" fn(*mut c_void,*mut *mut c_void)->i32>(b"ANeuralNetworksExecution_create").unwrap();
            let si = lib.get::<unsafe extern "C" fn(*mut c_void,i32,*const c_void,*const c_void,usize)->i32>(b"ANeuralNetworksExecution_setInput").unwrap();
            let so = lib.get::<unsafe extern "C" fn(*mut c_void,i32,*const c_void,*mut c_void,usize)->i32>(b"ANeuralNetworksExecution_setOutput").unwrap();
            let cp = lib.get::<unsafe extern "C" fn(*mut c_void)->i32>(b"ANeuralNetworksExecution_compute").unwrap();

            let mut exec: *mut c_void = std::ptr::null_mut();
            ce(comp, &mut exec);

            let off1 = (idx*32) % vesper.len();
            let off2 = ((idx+1)*32) % vesper.len();
            idx += 2;

            let in1 = &vesper[off1..off1+32];
            let in2 = &vesper[off2..off2+32];
            let mut out = [0u8; 32];

            si(exec, 0, std::ptr::null(), in1.as_ptr() as *const _, 32);
            si(exec, 1, std::ptr::null(), in2.as_ptr() as *const _, 32);
            so(exec, 0, std::ptr::null(), out.as_mut_ptr() as *mut _, 32);

            let start = Instant::now();
            let _ = cp(exec);
            let ns = start.elapsed().as_nanos();
            let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

            if ns < 500 {
                helped += 1;
                println!("REAL ADD: {} ns (h={} y={}) out[0]={:02x}", ns, helped, yielded, out[0]);
                log_csv(ts, ns, "ADD", helped, yielded);
            } else {
                yielded += 1;
                std::thread::sleep(Duration::from_millis(100));
                log_csv(ts, ns, "YIELD", helped, yielded);
            }

            if helped % 50 == 0 { notify(helped, yielded, ns); }
        }
        std::thread::sleep(Duration::from_millis(20));
    }
}
